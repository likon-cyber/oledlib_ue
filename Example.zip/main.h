#ifndef __MAIN_H
#define __MAIN_H

/***************************************
 * Proto interrupt handler
 ***************************************/

@far @interrupt void IRQ_Handler_TIM4(void);

#endif